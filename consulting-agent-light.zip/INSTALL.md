# 咨询 Agent Bundle 安装说明

## 文件说明

本 bundle 包含一套完整的咨询商业化能力标准化工具，基于 opencode 的 Skill + Sub-Agent 体系构建。

核心定位：**不内置行业方法论，而是提供「生成方法论的方法论」——元准则引擎**。

## 包含内容

```
consulting-agent-bundle/
├── INSTALL.md                        # 本文件
│
├── skill/                            # 主编排 Skill
│   └── consulting-workflow/
│       └── SKILL.md                  # 咨询项目标准化工作流（Step 1+2）
│
├── agents/                           # 子 Agent
│   ├── analyst-agent.md              # 框架融合+诊断+Cross-Check
│   ├── report-agent.md               # HTML 报告生成
│   ├── data-agent.md                 # 年报PDF解析+时间序列提取
│   ├── search-agent.md               # Tavily→tofu fallback搜索链
│   └── red-team-agent.md             # 红队对抗审查（独立审核报告）
│
├── data/
│   └── frameworks.json               # 模板库（17框架+路由表+融合规则）
│
└── data/projects/                    # 项目数据目录（初始为空）
```

## 安装步骤

### 前置条件

1. **opencode** 已安装并正常运行
2. **Tavily Search API Key** 已配置
   - 在 `~/.config/opencode/opencode.json` 中添加：
   ```json
   {
     "plugin": [
       "C:/Users/<你的用户名>/.config/opencode/node_modules/superpowers",
       "C:/Users/<你的用户名>/.config/opencode/plugins/tavily-search.mjs"
     ]
   }
   ```
   - 设置环境变量：`TAVILY_API_KEY=你的key`
   - 插件文件 `tavily-search.mjs` 需放在上述路径（见下方插件代码）

### 步骤 1: 复制文件到 opencode 项目

将本 bundle 解压到你的项目根目录（如 `C:\Users\<用户名>\PycharmProjects\consulting\`），确保目录结构如下：

```
项目根目录/
├── .opencode/
│   ├── skill/consulting-workflow/SKILL.md
│   └── agents/
│       ├── analyst-agent.md
│       ├── report-agent.md
│       ├── data-agent.md
│       ├── search-agent.md
│       └── red-team-agent.md
├── data/
│   ├── frameworks.json
│   └── projects/  (空目录，运行时自动填充)
└── docs/
    └── ...
```

### 步骤 2: 确认 Tavily 搜索插件已部署

在 `~/.config/opencode/plugins/` 下创建 `tavily-search.mjs`：

```javascript
import { tool } from "@opencode-ai/plugin";

export default async () => {
  const t = tool({
    description:
      "Search the web using Tavily AI-optimized search. " +
      "Use when you need to find current information, news, or facts on the internet. " +
      "Returns results with title, url, and content snippet.",
    args: {
      query: tool.schema.string().describe("Search query string"),
      max_results: tool.schema.number().optional().describe("Maximum results to return (default: 5)"),
    },
    async execute(args, ctx) {
      const apiKey = process.env.TAVILY_API_KEY;
      if (!apiKey) {
        return "Error: TAVILY_API_KEY not set. Set it in your environment.";
      }
      const body = {
        api_key: apiKey,
        query: args.query,
        search_depth: "basic",
        max_results: args.max_results ?? 5,
      };
      const resp = await fetch("https://api.tavily.com/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await resp.json();
      return JSON.stringify(data, null, 2);
    },
  });
  return { tool: { tavily_search: t } };
};
```

同时确保 `~/.config/opencode/opencode.json` 中已注册此插件路径。

### 步骤 3: 重启 opencode

退出并重新启动 opencode，新 Skill 和 Agent 将自动加载。

## 使用方式

### 新建项目

在 opencode 对话中输入（触发 consulting-workflow skill）：

```
帮我做一个咨询项目，公司是XX，主要问题是XX
```

或者直接说：

```
新建咨询项目
```

Agent 将自动进入 Step 1 流程，逐步引导。

### 回到已有项目

```
继续上次的咨询项目，项目名是XX
```

Agent 读取项目文件，从上次断点继续。

### 项目数据保存位置

所有项目数据保存在 `data/projects/<项目名>.json`，HTML 报告保存在同目录。

## 工作流概览

```
抽象 ──────────────────────────────────────────────→ 具象

Step 1: 项目设立   → 用户提供最少信息，Agent 自动补全客户画像
Step 2: 方法论+初版 → 生成专属方法论框架，执行内外诊断，出初版 HTML 报告
Step 3: 细化交付   → 深度验证、详细图表、终版报告（待开发）
```

每个 Step 结束时需要用户明确确认才进入下一步。

## 模板库说明

`data/frameworks.json` 包含 17 个咨询分析框架，按类别组织：
- **诊断类**：MECE 问题树、SWOT、5 Whys、鱼骨图、Gap 分析
- **战略类**：Porter 五力、PESTEL、BCG 矩阵、Ansoff 矩阵、蓝海战略、商业模式画布
- **运营类**：Profitability 框架、价值链分析、SIPOC、平衡计分卡
- **组织类**：McKinsey 7S
- **营销类**：3C、4P

每个框架定义了适用域、前置条件、可组合框架、不适用场景。路由规则自动根据问题领域推荐模板组合。

## 自定义

- 修改 `data/frameworks.json` 可增删模板或调整路由规则——无需改代码
- 修改 `agents/*.md` 可调整子 Agent 的行为
- 修改 `skill/consulting-workflow/SKILL.md` 可调整主编排流程和门禁逻辑
