"""
tofu-search MCP Server — lightweight Python wrapper for opencode.
No model loading, pure API calls to multi-engine search.
"""
import json
import sys
import asyncio
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

server = Server("tofu-search")


@server.list_tools()
async def list_tools():
    return [
        Tool(
            name="tofu_search",
            description="Multi-engine web search (DDG/Google/Bing via tofu). Use as fallback when Tavily is unavailable.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Search query"},
                    "max_results": {"type": "integer", "description": "Max results (default 5)", "default": 5},
                },
                "required": ["query"],
            },
        )
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict):
    if name != "tofu_search":
        return [TextContent(type="text", text=json.dumps({"error": f"unknown tool: {name}"}))]

    query = arguments.get("query", "")
    max_results = arguments.get("max_results", 5)
    try:
        from tofu_search import search
        results = search(query, max_results=max_results)
        formatted = []
        for r in results:
            formatted.append({
                "title": r.get("title", ""),
                "url": r.get("url", ""),
                "snippet": r.get("snippet", (r.get("full_content", "") or "")[:300]),
                "score": r.get("score", 0),
            })
        return [TextContent(type="text", text=json.dumps(formatted, ensure_ascii=False, indent=2))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({"error": str(e), "hint": "pip install tofu-search" if "No module named" in str(e) else ""}))]


async def main():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())
